package com.kgitbank.mvc01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.stereotype.Repository;

@Repository
public class MemberDAO {

	Connection con;
	public MemberDAO() {
		//1. Ŀ���� ����
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. Ŀ���� ����ok...");
			
			//2. db����
			String url = "jdbc:mysql://localhost:3309/spring";
			String user = "root";
			String password = "1234";
			con = DriverManager.getConnection(url, user, password);
			System.out.print("2. db ���� ok...");
			
		} catch (Exception e) {
		}
		
	}
	
	
	public void insert(MemberDTO dto) {
		try {
			
			//3. sql�� ����
			String sql = "insert into member values (?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setString(2, dto.getPw());
			ps.setString(3, dto.getName());
			ps.setString(4, dto.getTel());
			System.out.print("3. SQL�� ��üȭ ok...");
			
			
			//4. sql�� ����
			ps.executeUpdate();
			System.out.print("4. sql�� ���� ok...");
			
		} catch (Exception e) {
			
		}
		
	}
	public void delete(MemberDTO dto) {
		try {
			
			//3. sql�� ����
			String sql = "delete from member where id = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			System.out.print("3. SQL�� ��üȭ ok...");
			
			
			//4. sql�� ����
			ps.executeUpdate();
			System.out.print("4. sql�� ���� ok...");
			
		} catch (Exception e) {
			
		}
		
	}
	public void update(MemberDTO dto) {
		try {
			
			//3. sql�� ����
			String sql = "update member set tel = ? where id = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getTel());
			ps.setString(2, dto.getId());
			System.out.print("3. SQL�� ��üȭ ok...");
			
			
			//4. sql�� ����
			ps.executeUpdate();
			System.out.print("4. sql�� ���� ok...");
			
		} catch (Exception e) {
			
		}
		
	}
	
	public MemberDTO select(MemberDTO dto) {
		MemberDTO dto2 = null;
		try {
			//3. SQL�� ����
			String sql = "select * from member where id = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			//4. SQL�� ����
			ResultSet rs = ps.executeQuery();
			
			//5. �˻���� �޾ƿ;� ��. =>record �ϳ�!
			if(rs.next()) {
				dto2 = new MemberDTO();
				dto2.setId(rs.getString(1));
				dto2.setPw(rs.getString(2));
				dto2.setName(rs.getString(3));
				dto2.setTel(rs.getString(4));
				
				
//				System.out.println(id);
//				System.out.println(pw);
//				System.out.println(name);
//				System.out.println(tel);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dto2;
	}


	

	
}
